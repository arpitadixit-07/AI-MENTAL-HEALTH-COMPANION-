# ai_mental_health_companion_advanced.py

import streamlit as st
from textblob import TextBlob
import random
import matplotlib.pyplot as plt
from datetime import datetime
import pyttsx3

# ------------------- DATA -------------------
quotes = [
    ("Keep going, you’re stronger than you think.", "https://i.imgur.com/0y8Ftya.png"),
    ("Every day may not be good, but there is something good in every day.", "https://i.imgur.com/Qr4WZbs.png"),
    ("Your feelings are valid, and it’s okay to not be okay.", "https://i.imgur.com/Tk0b7QF.png"),
    ("Believe in yourself and all that you are.", "https://i.imgur.com/6Xy7F7E.png"),
    ("You are not alone. Keep moving forward.", "https://i.imgur.com/Nz5wP5D.png")
]

tips = [
    "💧 Drink at least 8 glasses of water today",
    "🌳 Take a 10-min walk outside",
    "✨ Write down 3 things you are grateful for",
    "🧘 Practice deep breathing for 5 minutes",
    "☎️ Talk to a close friend or family member"
]

if "history" not in st.session_state:
    st.session_state.history = []

# ------------------- APP CONFIG -------------------
st.set_page_config(page_title="AI Mental Health Companion", page_icon="🧠", layout="wide")

# Sidebar
st.sidebar.image("https://cdn-icons-png.flaticon.com/512/4712/4712027.png", width=100)
st.sidebar.title("🧠 Companion Menu")
page = st.sidebar.radio("Navigate", ["Home", "Chat", "Mood History", "Relaxation"])

# ------------------- HOME PAGE -------------------
if page == "Home":
    st.title("🌈 Welcome to AI Mental Health Companion")
    st.markdown("Your personal AI buddy to support your emotional well-being 💙")
    st.success(random.choice(tips))
    st.video("https://www.youtube.com/watch?v=inpok4MKVLM")  # Guided meditation

# ------------------- CHAT PAGE -------------------
elif page == "Chat":
    st.title("💬 Chat with Your AI Friend")
    user_input = st.text_area("How are you feeling today?", height=100)

    if st.button("Submit"):
        if user_input.strip() != "":
            blob = TextBlob(user_input)
            polarity = blob.sentiment.polarity

            if polarity > 0:
                mood = "😊 Positive"
                response = "I'm glad you're feeling good! Keep shining!"
            elif polarity < 0:
                mood = "😔 Negative"
                response = "I'm sorry you're feeling low. Remember, tough times don't last."
            else:
                mood = "😐 Neutral"
                response = "I see, thanks for sharing. Remember, it's okay to have calm days too."

            # Save to history
            st.session_state.history.append((datetime.now().strftime("%H:%M:%S"), user_input, mood))

            # Show response
            st.subheader("Your Mood")
            st.success(f"Detected mood: {mood}")

            st.subheader("AI Response")
            st.write(response)

            # Show motivational image
            quote, img = random.choice(quotes)
            st.image(img, caption=quote)

            # Voice output
            try:
                engine = pyttsx3.init()
                engine.say(response)
                engine.runAndWait()
            except:
                st.warning("Voice output not supported in this environment.")

# ------------------- MOOD HISTORY -------------------
elif page == "Mood History":
    st.title("📊 Mood Tracking Dashboard")

    if st.session_state.history:
        times = [entry[0] for entry in st.session_state.history]
        moods = [entry[2] for entry in st.session_state.history]

        mood_map = {"😊 Positive": 1, "😐 Neutral": 0, "😔 Negative": -1}
        values = [mood_map[m] for m in moods]

        st.line_chart(values)

        mood_counts = {m: moods.count(m) for m in set(moods)}
        fig, ax = plt.subplots()
        ax.pie(mood_counts.values(), labels=mood_counts.keys(), autopct='%1.1f%%')
        st.pyplot(fig)
    else:
        st.warning("No mood history yet. Start chatting!")

# ------------------- RELAXATION PAGE -------------------
elif page == "Relaxation":
    st.title("🌿 Relaxation Zone")
    st.markdown("Breathe in... Breathe out... 🧘")

    st.image("https://i.imgur.com/m9Y4YWB.gif", caption="Breathing Exercise")
    st.audio("https://www2.cs.uic.edu/~i101/SoundFiles/BabyElephantWalk60.wav")
